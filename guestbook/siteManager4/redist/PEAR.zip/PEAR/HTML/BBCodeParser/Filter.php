<?php
require_once 'HTML/BBCodeParser.php';

/**
*   Dummy class that filters need to extend from.
*/
class HTML_BBCodeParser_Filter extends HTML_BBCodeParser
{
}
?>